<?php 
    include 'head.php';
?>

<main id="main" class="main">

<div class="pagetitle">
  <h1>Sambungan Baru</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Home</a></li>
      <li class="breadcrumb-item">Pelayanan</li>
      <li class="breadcrumb-item active">Sambungan Baru</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section">
  <div class="row">
    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
          <h5 class="card-title"></h5>

          <!-- Multi Columns Form -->
          <form class="row g-3" action="aksi_penyambungan.php" method="post">
            <div class="col-md-12">
              <label for="inputName5" class="form-label">Nama</label>
              <input type="text" class="form-control" name="nama" value="<?= $_SESSION['username'] ?>" readonly>
            </div>
            <div class="col-md-6">
              <label for="inputState" class="form-label">Provinsi</label>
              <select id="inputState" class="form-select" name="provinsi">
                <option value="Sumatera Utara">Sumatera Utara</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="inputState" class="form-label">Kota/Kabupaten</label>
              <select id="inputState" class="form-select" name="kabupaten">
                <option value="Kota Medan">Kota Medan</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="inputState" class="form-label">Unit Layanan</label>
              <select id="inputState" class="form-select">
                <option value="Medan Timur">Medan Timur</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="inputState" class="form-label">Kecamatan</label>
              <select id="inputState" class="form-select" name="kecamatan">
                <option value="Medan Timur">Medan Timur</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="inputState" class="form-label">Desa/Kelurahan</label>
              <select id="inputState" class="form-select" name="desa">
                <option selected>Choose...</option>
                <option value="Rejo">Tegal Rejo</option>
                <option value="Sampali">Sampali</option>
                <option value="Saentis">Saentis</option>
                <option value="Percut">Percut</option>
                <option value="Indra Kasih">Indra Kasih</option>
                <option value="Sidorejo">Sidorejo</option>
                <option value="Sidorejo Hilir">Sidorejo Hilir</option>
              </select>
            </div>
            <div class="col-md-6">
                <label for="inputName5" class="form-label">Detail Alamat</label>
                <textarea name="alamat" cols="53" rows="5" class="form-control"></textarea>    
            </div>
            <div class="col-md-12">
              <label for="inputName5" class="form-label">Email</label>
              <input type="email" class="form-control" name="email">
            </div>
            <div class="col-md-6">
              <label for="inputEmail5" class="form-label">Nomor Whatsapp</label>
              <input type="text" class="form-control" id="inputEmail5" name="whatsapp">
            </div>
            <div class="col-md-6">
              <label for="inputPassword5" class="form-label">Nomor Telepon</label>
              <input type="text" class="form-control" id="inputPassword5" name="telepon">
            </div>
            <div class="col-md-12">
              <label for="inputState" class="form-label">Pilihan Penyambungan dan Harga</label>
              <select id="inputState" class="form-select" name="menu_harga">
                <option selected>Choose...</option>
                <option value="Biaya pasang listrik baru daya 450 VA: Rp.230.500">Biaya pasang listrik baru daya 450 VA: Rp.230.500</option>
                <option value="Biaya pasang listrik baru daya 900 VA: Rp.863.000">Biaya pasang listrik baru daya 900 VA: Rp.863.000</option>
                <option value="Biaya pasang listrik baru daya 1.300 VA: Rp.1.238.000">Biaya pasang listrik baru daya 1.300 VA: Rp.1.238.000</option>
                <option value="Biaya pasang listrik baru daya 2.200 VA: Rp.2.082.500">Biaya pasang listrik baru daya 2.200 VA: Rp.2.082.500</option>
                <option value="Biaya pasang listrik baru daya 3.500 VA: Rp.3.411.500">Biaya pasang listrik baru daya 3.500 VA: Rp.3.411.500</option>
                <option value="Biaya pasang listrik baru daya 4.400 VA: Rp.4.283.600">Biaya pasang listrik baru daya 4.400 VA: Rp.4.283.600</option>
                <option value="Biaya pasang listrik baru daya 5.500 VA: Rp.5.359.500">Biaya pasang listrik baru daya 5.500 VA: Rp.5.359.500</option>
                <option value="Biaya pasang listrik baru daya 6.600 VA: Rp.6.425.400">Biaya pasang listrik baru daya 6.600 VA: Rp.6.425.400</option>
                <option value="Biaya pasang listrik baru daya 7.700 VA: Rp.7.491.300">Biaya pasang listrik baru daya 7.700 VA: Rp.7.491.300</option>
              </select>
            </div>
            <input type="hidden" name="status_bayar" value="Belum Bayar">
            <input type="hidden" name="status" value="PENDING">
            <input type="hidden" name="teknisi" value="NONE">
            <div class="text-center">
              <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i>  Simpan</button>
            </div>
          </form><!-- End Multi Columns Form -->

        </div>
      </div>

    </div>

    </div>
  </div>
</section>

</main><!-- End #main -->

<?php include 'foot.php' ?>