<?php include 'head.php' ?>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <center>
        <br><br>
        <img src="../assets/img/logopln2.png" width="500px">
        <br><br><br>
        <h2>Sistem Informasi Pelayanan Pemasangan Listrik<br>PLN UP3 Medan Timur</h2>
        <br><br><br><br>
      </center>
    </section>

  </main><!-- End #main -->

<?php include 'foot.php'?>